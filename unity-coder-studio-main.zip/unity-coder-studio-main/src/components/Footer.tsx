import { Github, Twitter, Linkedin, Mail, Youtube, ExternalLink } from 'lucide-react';

const socialLinks = [
  { name: 'GitHub', icon: Github, href: '#', label: 'View my code repositories' },
  { name: 'Twitter', icon: Twitter, href: '#', label: 'Follow for updates' },
  { name: 'LinkedIn', icon: Linkedin, href: '#', label: 'Connect professionally' },
  { name: 'YouTube', icon: Youtube, href: '#', label: 'Watch dev logs' },
  { name: 'Email', icon: Mail, href: 'mailto:hello@example.com', label: 'Get in touch' }
];

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer id="contact" className="py-16 border-t border-border relative">
      {/* Background accent */}
      <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent pointer-events-none" />
      
      <div className="container px-4 relative z-10">
        {/* Main footer content */}
        <div className="text-center mb-12">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4 code-text">
            Let's <span className="text-primary text-glow">Create</span> Together
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto mb-8">
            Interested in collaborating on a project? Have a game idea you want to bring to life? 
            I'm always open to new opportunities and creative challenges.
          </p>
          
          {/* Contact button */}
          <a 
            href="mailto:hello@example.com"
            className="inline-flex items-center gap-2 px-8 py-3 bg-primary text-primary-foreground 
                     font-semibold rounded-lg hover:bg-primary/90 transition-all duration-300 
                     box-glow hover:box-glow-intense"
          >
            <Mail size={18} />
            Send Me a Message
          </a>
        </div>

        {/* Social links */}
        <div className="flex justify-center gap-4 mb-12">
          {socialLinks.map((social) => (
            <a
              key={social.name}
              href={social.href}
              aria-label={social.label}
              className="group p-3 rounded-lg border border-border bg-card 
                       hover:border-primary/50 hover:bg-primary/10 transition-all duration-300"
            >
              <social.icon 
                size={20} 
                className="text-muted-foreground group-hover:text-primary transition-colors" 
              />
            </a>
          ))}
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent mb-8" />

        {/* Bottom section */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <span className="code-text text-primary">{'<'}</span>
            <span>Alex GameDev</span>
            <span className="code-text text-primary">{'/>'}</span>
          </div>
          
          <nav className="flex gap-6">
            <a href="#about" className="hover:text-primary transition-colors">About</a>
            <a href="#projects" className="hover:text-primary transition-colors">Projects</a>
            <a href="#skills" className="hover:text-primary transition-colors">Skills</a>
          </nav>
          
          <p className="code-text">
            © {currentYear} <span className="text-primary">All rights reserved</span>
          </p>
        </div>

        {/* Easter egg terminal line */}
        <div className="mt-8 text-center">
          <span className="code-text text-xs text-muted-foreground/50">
            {'>'} built with passion.exit()
          </span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

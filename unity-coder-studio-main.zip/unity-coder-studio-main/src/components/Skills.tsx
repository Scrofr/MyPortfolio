import { Code, Palette, Music, Cpu, Boxes, PenTool } from 'lucide-react';

const skills = [
  {
    name: 'Unity',
    level: 95,
    icon: Boxes,
    description: 'Advanced 2D/3D game development'
  },
  {
    name: 'C#',
    level: 90,
    icon: Code,
    description: 'Object-oriented programming & patterns'
  },
  {
    name: 'Python',
    level: 75,
    icon: Cpu,
    description: 'Tools, automation & prototyping'
  },
  {
    name: 'Game Design',
    level: 85,
    icon: PenTool,
    description: 'Mechanics, balance & player experience'
  },
  {
    name: 'Pixel Art',
    level: 70,
    icon: Palette,
    description: 'Sprites, animations & visual style'
  },
  {
    name: 'Music Production',
    level: 65,
    icon: Music,
    description: 'Soundtracks & audio design'
  }
];

const Skills = () => {
  return (
    <section id="skills" className="py-24 relative">
      <div className="container px-4">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="code-text text-primary text-sm mb-2 block">
            {'// '}SKILLS
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Technical Expertise
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A diverse skill set spanning programming, design, and creative arts—everything 
            needed to bring game ideas to life.
          </p>
        </div>

        {/* Skills grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {skills.map((skill, index) => (
            <div 
              key={skill.name}
              className="group p-6 rounded-xl bg-card border border-border
                       hover:border-primary/50 transition-all duration-300"
            >
              {/* Header */}
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 rounded-lg bg-primary/10 text-primary group-hover:bg-primary/20 
                              group-hover:box-glow transition-all duration-300">
                  <skill.icon size={24} />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground code-text">
                    {skill.name}
                  </h3>
                  <p className="text-xs text-muted-foreground">
                    {skill.description}
                  </p>
                </div>
              </div>

              {/* Progress bar */}
              <div className="relative">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Proficiency</span>
                  <span className="text-primary code-text">{skill.level}%</span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-primary rounded-full transition-all duration-1000 ease-out
                             group-hover:box-glow"
                    style={{ 
                      width: `${skill.level}%`,
                      boxShadow: 'var(--glow-primary)'
                    }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Additional tools */}
        <div className="mt-16 text-center">
          <p className="text-muted-foreground mb-6">Also experienced with:</p>
          <div className="flex flex-wrap justify-center gap-3 max-w-3xl mx-auto">
            {[
              'Git', 'Visual Studio', 'Aseprite', 'FL Studio', 
              'Blender', 'Photoshop', 'Trello', 'Discord API'
            ].map((tool) => (
              <span 
                key={tool}
                className="px-4 py-2 text-sm bg-secondary text-secondary-foreground rounded-full
                         hover:bg-primary/10 hover:text-primary transition-colors cursor-default"
              >
                {tool}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;

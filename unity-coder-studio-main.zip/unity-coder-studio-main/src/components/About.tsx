import { Gamepad2, Code2, Sparkles } from 'lucide-react';

const About = () => {
  const highlights = [
    {
      icon: Gamepad2,
      title: 'Game Creator',
      description: 'Crafting immersive gaming experiences that captivate players'
    },
    {
      icon: Code2,
      title: 'Clean Code',
      description: 'Writing maintainable, performant code with industry best practices'
    },
    {
      icon: Sparkles,
      title: 'Creative Vision',
      description: 'Bringing unique ideas to life through interactive entertainment'
    }
  ];

  return (
    <section id="about" className="py-24 relative">
      <div className="container px-4">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="code-text text-primary text-sm mb-2 block">
            {'// '}ABOUT_ME
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            The Developer Behind The Games
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text content */}
          <div className="space-y-6">
            <p className="text-lg text-muted-foreground leading-relaxed">
              Hello! I'm a passionate <span className="text-primary">game developer</span> with a deep love 
              for creating interactive experiences that tell stories and challenge players. With expertise 
              in <span className="text-primary">Unity</span> and <span className="text-primary">C#</span>, 
              I transform creative concepts into polished, playable games.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              My journey in game development started with a fascination for how games make us feel—the 
              excitement, the challenge, the satisfaction. Today, I channel that passion into every 
              project, whether it's a story-driven RPG, an addictive puzzle game, or an innovative 
              indie experience.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              When I'm not coding, you'll find me experimenting with pixel art, composing game music, 
              or exploring the latest releases for inspiration. I believe great games are born from the 
              intersection of <span className="text-primary">technical excellence</span> and 
              <span className="text-primary"> creative vision</span>.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-6">
              {[
                { value: '5+', label: 'Years Experience' },
                { value: '12+', label: 'Projects Completed' },
                { value: '50K+', label: 'Players Reached' }
              ].map((stat) => (
                <div key={stat.label} className="text-center p-4 rounded-lg bg-card border border-border">
                  <div className="text-2xl md:text-3xl font-bold text-primary text-glow">{stat.value}</div>
                  <div className="text-xs md:text-sm text-muted-foreground mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Highlight cards */}
          <div className="space-y-4">
            {highlights.map((item, index) => (
              <div 
                key={item.title}
                className="group p-6 rounded-xl gradient-border border border-border
                         hover:border-primary/50 transition-all duration-300"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-lg bg-primary/10 text-primary group-hover:bg-primary/20 transition-colors">
                    <item.icon size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2 code-text">
                      {item.title}
                    </h3>
                    <p className="text-muted-foreground">{item.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;

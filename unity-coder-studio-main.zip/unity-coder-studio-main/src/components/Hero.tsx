import { useEffect, useState } from 'react';
import { ChevronDown } from 'lucide-react';

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const scrollToAbout = () => {
    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background gradient */}
      <div 
        className="absolute inset-0 opacity-50"
        style={{ background: 'var(--gradient-hero)' }}
      />
      
      {/* Animated grid background */}
      <div className="absolute inset-0 opacity-10">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(hsl(var(--primary) / 0.1) 1px, transparent 1px),
              linear-gradient(90deg, hsl(var(--primary) / 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      {/* Content */}
      <div className="container relative z-10 text-center px-4">
        <div 
          className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {/* Terminal-style intro */}
          <div className="inline-block mb-6">
            <span className="code-text text-primary text-sm md:text-base">
              <span className="text-muted-foreground">{'>'}</span> initializing developer_profile
              <span className="animate-blink">_</span>
            </span>
          </div>

          {/* Name */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 tracking-tight">
            <span className="text-foreground">ALEX </span>
            <span className="text-primary text-glow">GAMEDEV</span>
          </h1>

          {/* Title */}
          <p className="code-text text-lg md:text-xl lg:text-2xl text-muted-foreground mb-8">
            <span className="text-primary">{'<'}</span>
            Unity Developer & Game Designer
            <span className="text-primary">{' />'}</span>
          </p>

          {/* Specialization badges */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {['Unity', 'C#', 'Game Design'].map((skill, index) => (
              <span 
                key={skill}
                className="px-4 py-2 rounded-full border border-primary/30 bg-primary/5 text-primary code-text text-sm
                         hover:bg-primary/10 hover:border-primary/50 transition-all duration-300"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {skill}
              </span>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-3 bg-primary text-primary-foreground font-semibold rounded-lg
                       hover:bg-primary/90 transition-all duration-300 box-glow hover:box-glow-intense"
            >
              View My Work
            </button>
            <button 
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-3 border border-primary/50 text-primary rounded-lg
                       hover:bg-primary/10 transition-all duration-300"
            >
              Get In Touch
            </button>
          </div>
        </div>

        {/* Scroll indicator */}
        <button 
          onClick={scrollToAbout}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-primary animate-float cursor-pointer"
        >
          <ChevronDown size={32} />
        </button>
      </div>
    </section>
  );
};

export default Hero;

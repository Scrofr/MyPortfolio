import { useState, useEffect } from 'react';
import { Menu, X, Gamepad2 } from 'lucide-react';

const navLinks = [
  { name: 'About', href: '#about' },
  { name: 'Projects', href: '#projects' },
  { name: 'Skills', href: '#skills' },
  { name: 'Contact', href: '#contact' }
];

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setIsMobileMenuOpen(false);
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-background/80 backdrop-blur-lg border-b border-border' 
          : 'bg-transparent'
      }`}
    >
      <nav className="container px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <Gamepad2 
            size={24} 
            className="text-primary group-hover:text-glow transition-all" 
          />
          <span className="code-text font-bold text-lg">
            <span className="text-foreground">Alex</span>
            <span className="text-primary">Dev</span>
          </span>
        </a>

        {/* Desktop navigation */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.name}
              onClick={() => handleNavClick(link.href)}
              className="text-muted-foreground hover:text-primary transition-colors duration-200
                       relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 
                       after:bg-primary after:transition-all hover:after:w-full"
            >
              {link.name}
            </button>
          ))}
          <button 
            onClick={() => handleNavClick('#contact')}
            className="px-4 py-2 bg-primary/10 text-primary border border-primary/30 rounded-lg
                     hover:bg-primary/20 hover:border-primary/50 transition-all duration-200"
          >
            Hire Me
          </button>
        </div>

        {/* Mobile menu button */}
        <button 
          className="md:hidden p-2 text-foreground"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div 
        className={`md:hidden absolute top-16 left-0 right-0 bg-background/95 backdrop-blur-lg 
                  border-b border-border transition-all duration-300 ${
          isMobileMenuOpen 
            ? 'opacity-100 translate-y-0' 
            : 'opacity-0 -translate-y-4 pointer-events-none'
        }`}
      >
        <div className="container px-4 py-4 flex flex-col gap-4">
          {navLinks.map((link) => (
            <button
              key={link.name}
              onClick={() => handleNavClick(link.href)}
              className="text-left py-2 text-muted-foreground hover:text-primary transition-colors"
            >
              {link.name}
            </button>
          ))}
          <button 
            onClick={() => handleNavClick('#contact')}
            className="py-2 bg-primary text-primary-foreground rounded-lg text-center
                     hover:bg-primary/90 transition-colors"
          >
            Hire Me
          </button>
        </div>
      </div>
    </header>
  );
};

export default Navbar;

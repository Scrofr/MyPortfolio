import { ExternalLink, Github, Gamepad } from 'lucide-react';

const projects = [
  {
    title: 'Realm of Shadows',
    category: 'RPG',
    description: 'A dark fantasy RPG with deep narrative, turn-based combat, and character progression. Features over 40 hours of gameplay.',
    tags: ['Unity', 'C#', 'Narrative Design'],
    gradient: 'from-purple-500/20 to-blue-500/20',
    featured: true
  },
  {
    title: 'Mind Bender',
    category: 'Puzzle',
    description: 'A physics-based puzzle game that challenges players with increasingly complex spatial reasoning problems.',
    tags: ['Unity', 'C#', 'Physics'],
    gradient: 'from-blue-500/20 to-cyan-500/20',
    featured: false
  },
  {
    title: 'Neon Runner',
    category: 'Endless Runner',
    description: 'Fast-paced cyberpunk runner with procedural level generation and electronic soundtrack.',
    tags: ['Unity', 'C#', 'Procedural Gen'],
    gradient: 'from-pink-500/20 to-purple-500/20',
    featured: false
  },
  {
    title: 'Pixel Dungeon',
    category: 'Roguelike',
    description: 'Retro-styled dungeon crawler with permadeath, randomized loot, and pixel art aesthetics.',
    tags: ['Unity', 'C#', 'Pixel Art'],
    gradient: 'from-orange-500/20 to-red-500/20',
    featured: true
  },
  {
    title: 'Space Colony',
    category: 'Strategy',
    description: 'Build and manage your space colony. Balance resources, research technology, and survive alien threats.',
    tags: ['Unity', 'C#', 'AI Systems'],
    gradient: 'from-green-500/20 to-teal-500/20',
    featured: false
  },
  {
    title: 'Battle Cards',
    category: 'Card Game',
    description: 'Strategic card battler with deck building mechanics and online multiplayer support.',
    tags: ['Unity', 'C#', 'Multiplayer'],
    gradient: 'from-yellow-500/20 to-orange-500/20',
    featured: false
  }
];

const Projects = () => {
  return (
    <section id="projects" className="py-24 relative">
      {/* Background accent */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent" />
      
      <div className="container px-4 relative z-10">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="code-text text-primary text-sm mb-2 block">
            {'// '}PROJECTS
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Featured Game Projects
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A collection of games I've developed, from concept to completion. Each project represents 
            unique challenges and creative solutions.
          </p>
        </div>

        {/* Projects grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <div 
              key={project.title}
              className={`group relative rounded-xl overflow-hidden border border-border bg-card
                        hover:border-primary/50 transition-all duration-500 hover:-translate-y-2
                        ${project.featured ? 'md:col-span-1' : ''}`}
            >
              {/* Thumbnail placeholder */}
              <div className={`relative h-48 bg-gradient-to-br ${project.gradient}`}>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Gamepad 
                    size={48} 
                    className="text-foreground/20 group-hover:text-primary/40 transition-colors duration-300" 
                  />
                </div>
                
                {/* Category badge */}
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 text-xs font-medium bg-background/80 backdrop-blur-sm 
                                 text-primary rounded-full border border-primary/30">
                    {project.category}
                  </span>
                </div>

                {/* Action buttons */}
                <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-2 rounded-full bg-background/80 backdrop-blur-sm text-foreground 
                                   hover:text-primary transition-colors">
                    <Github size={16} />
                  </button>
                  <button className="p-2 rounded-full bg-background/80 backdrop-blur-sm text-foreground 
                                   hover:text-primary transition-colors">
                    <ExternalLink size={16} />
                  </button>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-2 code-text group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                  {project.description}
                </p>
                
                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span 
                      key={tag}
                      className="px-2 py-1 text-xs bg-secondary text-secondary-foreground rounded"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Hover glow effect */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
                <div className="absolute inset-0 bg-gradient-to-t from-primary/10 to-transparent" />
              </div>
            </div>
          ))}
        </div>

        {/* View more button */}
        <div className="text-center mt-12">
          <button className="px-8 py-3 border border-primary/50 text-primary rounded-lg
                           hover:bg-primary/10 transition-all duration-300 code-text">
            View All Projects →
          </button>
        </div>
      </div>
    </section>
  );
};

export default Projects;
